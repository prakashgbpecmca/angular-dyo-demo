export class Access {
    constructor(
        public WMSAccessModuleUser: any,
        public AccessControlModule: any,
        public UserId:number
    ) {}
}