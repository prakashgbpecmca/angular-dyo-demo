export class Product {
    public ProductName: string;
    public ProductSKUCode: string;
    public ProducSize: string;
    public ProductUnit: string;
    public ProductType: string;
    public ProductColor: string;
    public ProductDescription: string;
    public ProductCaption: string;
    public ProductTag: string;
}
