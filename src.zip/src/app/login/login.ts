export class UserLogin {
  UserName: string;
  Password: string;
}

