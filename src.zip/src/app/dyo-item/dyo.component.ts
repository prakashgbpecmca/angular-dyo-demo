import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-dyo",
  templateUrl: "./dyo.component.html",
  })
export class DyoComponent {

  constructor(
  ) {

}}

